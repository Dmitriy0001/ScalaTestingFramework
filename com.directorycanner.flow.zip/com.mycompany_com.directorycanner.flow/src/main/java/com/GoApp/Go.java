/*
 * 2. Модифицировать приложение из задачи 1 следующим образом:
- один поток производит поиск
- другой поток выводить на консоль результаты по мере их появления.
Результаты работы обоих потоков выводить на консоль.

 */
package com.GoApp;

import com.flow.FlowOne;
import com.flow.FlowTwo;
import java.util.concurrent.ArrayBlockingQueue;

/**
     * Start applications
     */


public class Go {

   
    public static void main(String[] args)   {
       
        
        
        
        ArrayBlockingQueue <String> listFileMask = new ArrayBlockingQueue(40) ;
        // stream parsing
        FlowOne flowOne = new FlowOne(listFileMask);
        flowOne.start();
        
        // Print the results to the console
        FlowTwo flowTwo = new FlowTwo(listFileMask);
        flowTwo.start();
        
        
        
        
        
        
        }
       
    }



