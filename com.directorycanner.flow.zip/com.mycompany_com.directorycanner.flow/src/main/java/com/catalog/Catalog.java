/*
 * Объкт-парсер. Получем необходимые элементы дерева каталога файлов с заданой глубиной
 * 
 * 
 */
package com.catalog;

import java.io.File;
import java.util.ArrayDeque;
import java.util.Queue;
import com.interfaces.ParserCatalogInterface;
import java.util.concurrent.ArrayBlockingQueue;

public class Catalog implements ParserCatalogInterface {

    private Queue<File> listFileCataloga = new ArrayDeque<>();

    private String rootPachtString;
    private int dethInt;
    private String maskString;

// Initialization of variables String rootPacht, int deth, String mask
    public Catalog(String rootPachtString, int dethInt, String maskString) {
        this.rootPachtString = rootPachtString;
        this.dethInt = dethInt;
        this.maskString = maskString;
    }

    @Override
    public void readCatalog(ArrayBlockingQueue<String> nameListMask) {

// Start parsing
        File dir = new File(rootPachtString);

        // Check rootPacht the directory or file
        if (dir.isDirectory()) {
            listFileCataloga.offer(dir);
        }
        if (dir.isFile()) {
            System.out.print("Директории не сущетсвует по заданому пути");
        }

// Create a loop to parse. dethInt - Refine your search depth
        while (dethInt != 0) {

            File file = listFileCataloga.poll();

            if (file.isDirectory()) {

                for (File nameFile : file.listFiles()) {

                    listFileCataloga.offer(nameFile);

                    if (nameFile.getName().contains(maskString)) {

                        nameListMask.add((nameFile.getName()));

                    }

                } // end 
            } else if (file.getName().contains(maskString)) {

                nameListMask.add((file.getName()));
            }

            dethInt--;
            if (dethInt == 0) {
                nameListMask.add("stop");

                break;
            }
        }
    }

    public Queue<File> getListFileCataloga() {
        return listFileCataloga;
    }

    public void setListFileCataloga(Queue<File> listFileCataloga) {
        this.listFileCataloga = listFileCataloga;
    }

    public String getRootPachtString() {
        return rootPachtString;
    }

    public void setRootPachtString(String rootPachtString) {
        this.rootPachtString = rootPachtString;
    }

    public int getDethInt() {
        return dethInt;
    }

    public void setDethInt(int dethInt) {
        this.dethInt = dethInt;
    }

    public String getMaskString() {
        return maskString;
    }

    public void setMaskString(String maskString) {
        this.maskString = maskString;
    }

}
