/*
 * The object to retrieve data from the console . 
 *  private String rootPacht;
    private int deth;
    private String mask;
 * 
 */
package com.consol;

import com.interfaces.ReadConsolInterface;
import java.util.Scanner;


public class Consol implements ReadConsolInterface {

    private String rootPacht;
    private int deth;
    private String mask;

    @Override
    public void readConsol() {

        Scanner in = new Scanner(System.in);

        System.out.print("Ведите путь к директории: ");//

       // Requesting rootPacht
        if (in.hasNextLine()) {
            rootPacht = in.nextLine();//

        }

       // Requesting deth> 0
       
        System.out.print("Ведите число глубины поиска: ");//
deth = in.nextInt();//
        

if (deth>=0) {
            deth = in.nextInt();//

        } else {
            System.out.print("Ведите неотрицательное число больше нуля: ");

            deth = in.nextInt();
        }

        // Requesting mask
        System.out.print("Ведите шаблон поиска файлов: ");//

        if (in.hasNextLine()) {

            mask = in.next();//
        }

    }

    public String getRootPacht() {
        return rootPacht;
    }

    public void setRootPacht(String rootPacht) {
        this.rootPacht = rootPacht;
    }

    public int getDeth() {
        return deth;
    }

    public void setDeth(int deth) {
        this.deth = deth;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

}
