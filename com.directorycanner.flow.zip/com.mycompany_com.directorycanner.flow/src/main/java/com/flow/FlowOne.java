/*
 * Stream parsing
 */
package com.flow;

import com.catalog.Catalog;
import com.consol.Consol;
import java.util.concurrent.ArrayBlockingQueue;


public class FlowOne extends Thread {

    Consol сonsol;
    Catalog catalog;
    ArrayBlockingQueue<String> nameListMask;

    public FlowOne(ArrayBlockingQueue<String> nameListMask) {
        this.nameListMask = nameListMask;
    }

    

    @Override
    public void run() {

        // Read data from the console
        сonsol = new Consol();
        сonsol.readConsol();
       

        // The parser tree file system directory
         
        catalog = new Catalog(сonsol.getRootPacht(), сonsol.getDeth(), сonsol.getMask());
        catalog.readCatalog(nameListMask);
        
       
         
        
       
 
 
    }

}
