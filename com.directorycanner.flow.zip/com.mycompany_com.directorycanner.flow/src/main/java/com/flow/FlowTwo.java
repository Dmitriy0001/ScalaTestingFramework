/*
 * Print data in the console second stream
 */
package com.flow;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FlowTwo extends Thread {

    ArrayBlockingQueue<String> listFileMask;

    public FlowTwo(ArrayBlockingQueue<String> listFileMask) {
        this.listFileMask = listFileMask;
    }

    @Override
    public void run() {

        while (!"stop".equals(listFileMask.peek())) {

            try {
                System.out.println(listFileMask.take());
            } catch (InterruptedException ex) {
                Logger.getLogger(FlowTwo.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }
}
