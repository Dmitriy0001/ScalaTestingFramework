/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.flow;

import com.catalog.Catalog;
import com.server.DataForServera;
import java.util.concurrent.ArrayBlockingQueue;


public class FlowOne extends Thread {

    DataForServera dataForServera;
    Catalog catalog;
    ArrayBlockingQueue<String> nameListMask;

    public FlowOne(DataForServera dataForServera, ArrayBlockingQueue<String> nameListMask) {
       
        this.dataForServera = dataForServera;
        this.nameListMask = nameListMask;
    }

   

    

    @Override
    public void run() {

        

        // Парсер дерева каталога файловой системы
         
        catalog = new Catalog(dataForServera.getRootPath(), dataForServera.getDepth(), dataForServera.getMask());
        catalog.readCatalog(nameListMask);
        
       
         
        
       
 
 
    }

}
