/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.flow;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Vovan
 */
public class FlowTwo extends Thread {

    

    ArrayBlockingQueue <String> listFileMask;

    public FlowTwo(ArrayBlockingQueue<String> listFileMask) {
        this.listFileMask = listFileMask;
    }
    
    
   
    
     
    @Override
     public void run() {
     
    
     while (!"stop".equals(listFileMask.peek())) {
         
         
         try {
             listFileMask.take();
         } catch (InterruptedException ex) {
             Logger.getLogger(FlowTwo.class.getName()).log(Level.SEVERE, null, ex);
         }
     
     
     }
     

     
     
    
    
}
}
