/*
 * Интерфес реализовывает каждый объект , который является парсером дерева каталога файлов
 */
package com.interfaces;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedTransferQueue;

/**
 *
 * @author Vovan
 */
public interface ParserCatalogInterface {

    void readCatalog( ArrayBlockingQueue <String> nameListMask);
    
}
