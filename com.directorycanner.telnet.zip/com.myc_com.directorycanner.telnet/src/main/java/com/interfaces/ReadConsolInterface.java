/*
 * Интерфес реализовывает каждый объект , для чтения данных с консоли
 * 
 * 
 */
package com.interfaces;

import java.util.concurrent.ArrayBlockingQueue;

/**
 *
 * @author Vovan
 */
public interface ReadConsolInterface {

    void readConsol();
    
}
