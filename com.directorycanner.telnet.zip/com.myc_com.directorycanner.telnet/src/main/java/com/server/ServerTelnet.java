/*
 * Класс для установки контакта с клиентом
 * 
 * 
 */
package com.server;

import com.flow.FlowOne;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

//server class
public class ServerTelnet {

    public ServerTelnet(DataForServera dataForServera) {
        this.dataForServera = dataForServera;
    }

    DataForServera dataForServera;

    public void getSoket() {

        try {
            ServerSocket serverSocket = new ServerSocket(dataForServera.getServerPort());

            while (true) {

                Socket socket = serverSocket.accept();

                DataInputStream in = new DataInputStream(socket.getInputStream());//
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());// 

                out.writeUTF("Ведите число - глубину поиска по каталогу");

                
                dataForServera.setDepth(in.readInt());

                out.writeBytes("Ведите mask - шаблон поиска файлов");
                
                dataForServera.setMask(in.readUTF());

                
                startReadTreeFile(out);

            }

        } catch (IOException ex) {
            Logger.getLogger(ServerTelnet.class.getName()).log(Level.SEVERE, null, ex);
        }

    } // end getSoket

    public void startReadTreeFile(DataOutputStream out) {

        ArrayBlockingQueue<String> listFileMask = new ArrayBlockingQueue(100);

        FlowOne flowOne = new FlowOne(dataForServera, listFileMask);
        flowOne.start();

        while (!"stop".equals(listFileMask.peek())) {

            try {
                out.writeUTF(listFileMask.poll());
            } catch (IOException ex) {
                Logger.getLogger(ServerTelnet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
