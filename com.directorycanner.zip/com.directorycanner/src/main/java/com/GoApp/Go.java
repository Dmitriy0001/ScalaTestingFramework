/*
 * 1. Обход дерева на заданную глубину без использования рекурсии.
 Написать консольное приложение на Java, которое принимает три параметра:
- путь к начальной директории (rootPath)
- глубина поиска - неотрицательное целое число (depth)
- маска - строка (mask)
Приложение должно найти все элементы дерева файловой системы находящиеся на
глубине depth от корня дерева rootPath, которые в своем имени содержат строку mask.
Требования:
- Приложение должно быть реализовано БЕЗ использования рекурсии.
- Приложение не должно зависеть от ОС.
 */
package com.GoApp;

import com.catalog.Catalog;
import com.consol.Consol;
import java.io.File;


public class Go {

    /**
     * Start applications
     */
    public static void main(String[] args) {

        // Getting the data from the console
        Consol consol = new Consol();
        consol.readConsol();

        // Parsing the file system elements
        Catalog catalog = new Catalog(consol.getRootPacht(), consol.getDeth(), consol.getMask());
        catalog.readCatalog();

       
// Print the results to the console

        for (String nameListMask : catalog.getListMask()) {

            System.out.println("Список найденых файлов mask " + nameListMask);// name

        }

    }

}
