/*
 * Class parser. It collects information about the file system elements
 * 
 * 
 */
package com.catalog;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import com.interfaces.ParserCatalogInterface;

final public class Catalog implements ParserCatalogInterface {

    private Queue<File> listFile = new ArrayDeque<>();

    private ArrayList<String> listMask = new ArrayList();
    private String rootPachtString;
    private int dethInt;
    private String maskString;

// Initialization of variables String rootPacht, int deth, String mask
    public Catalog(String rootPacht, int deth, String mask) {
        this.rootPachtString = rootPacht;
        this.dethInt = deth;
        this.maskString = mask;
    }

    @Override
    public void readCatalog() {

// Start parsing
        File dir = new File(rootPachtString);

        // Check rootPacht the directory or file
        if (dir.isDirectory()) {
            listFile.offer(dir);
        }
        if (dir.isFile()) {
            System.out.print("Директории не сущетсвует по заданому пути");
        }

// Create a loop to parse. dethInt - Refine your search depth
        while (dethInt != 0) {

            File file = listFile.poll();

            if (file.isDirectory()) {

                for (File nameFile : file.listFiles()) {

                    listFile.offer(nameFile);

                    if (nameFile.getName().contains(maskString)) {

                        listMask.add(nameFile.getName());

                    }

                }
            } else if (file.getName().contains(maskString)) {

                listMask.add(file.getName());

            }

            dethInt--;
            if (dethInt == 0) {
                break;
            }

        }
    }

    public Queue<File> getListFile() {
        return listFile;
    }

    public void setListFile(Queue<File> listFile) {
        this.listFile = listFile;
    }

    public ArrayList<String> getListMask() {
        return listMask;
    }

    public void setListMask(ArrayList<String> listMask) {
        this.listMask = listMask;
    }

    public String getRootPachtString() {
        return rootPachtString;
    }

    public void setRootPachtString(String rootPachtString) {
        this.rootPachtString = rootPachtString;
    }

    public int getDethInt() {
        return dethInt;
    }

    public void setDethInt(int dethInt) {
        this.dethInt = dethInt;
    }

    public String getMaskString() {
        return maskString;
    }

    public void setMaskString(String maskString) {
        this.maskString = maskString;
    }

}
