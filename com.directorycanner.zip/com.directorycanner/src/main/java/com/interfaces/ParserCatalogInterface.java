/*
 * Интерфес реализовывает каждый объект , который является парсером дерева каталога файлов
 */
package com.interfaces;

/**
 *
 * @author Vovan
 */
public interface ParserCatalogInterface {

    void readCatalog();
    
}
