/*
 * Интерфес реализовывает каждый объект , для чтения данных с консоли
 * 
 * 
 */
package com.interfaces;

/**
 *
 * @author Vovan
 */
public interface ReadConsolInterface {

    void readConsol();
    
}
